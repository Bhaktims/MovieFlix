
const express = require("express");

const morgan = require("morgan")
const movieRouter = require('./Routes/movieRoutes') // using this we can create extra router
// const { connect } = require("http2");
let app = express();
app.use(express.json()) // we can add some extra info in our website/browser throught forms that suppose to be reach at our applictaion for that purpose we use 

const logger = (req,res,next)=>{
    req.startTime = new Date().toISOString();
    console.log(req.startTime);
    next()
}

app.use(logger)
if(process.env.NODE_ENV == 'dev'){
    app.use(morgan("combined"));
}
// app.use(morgan("dev"))
// app.use(morgan("tiny"))


//use is middleware that helps to get req body data in json format 
// before client request reaches the server 
//lh:3000/addMovie +{movie info in json} => server 
app.use(express.static('./public'))// if any static file requested using static app can navigate at that page
app.use('/',movieRouter)

//readfile sync gives data in buffer in hexadecimal format
//JSON parse function will convert that data in array of object



// app.get("/getAllMovies",getallmovies)
// app.post("/addMovie",addnewmovie)
// app.get('/getMovie/:nryear',getmoviebyryear)
// app.get('/getMoviebyid/:mid/:mname?',getmoviebyid)
// app.put('/updteMovie/:mid',updatemoviebyput)
// app.patch('/updateMovie/:mid',updatemoviebypatch)
// app.delete("/deleteMovie/:mid",deletemovie)
// app.delete("/deleteAllMovies",deleteallmovies)


module.exports = app;


