const dotenv = require('dotenv')
dotenv.config({path:'./config.env'});
// console.log(process.env) 

const app = require('./app.js')
console.log(app.get('env')) // all app on node dafaultly run on developement  - test - qa

const port = process.env.PORT || 5000; 
//in config.env file we have mentioned port 3000, if we remove tht and then in port case we can give or situation using ||
//now if 3000 is not available then 5000 will work 

app.listen(port,()=>{
    console.log("Go to Browser and request your URL")
})

// console.log(process.env)// whatever we set it get added like set x=100 y=200
