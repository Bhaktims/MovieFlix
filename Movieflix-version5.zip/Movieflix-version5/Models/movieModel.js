
const mongoose = require('mongoose');
// mongoose.connect("mongodb+srv://bhaktishan10:bhaktishan10@cluster0.cjrhuwy.mongodb.net/Movieflixdb??retryWrites=true&w=majority",{useNewUrlParser:true})
mongoose.connect(process.env.CONN_STR,{useNewUrlParser:true})
  .then((conn)=>{
    // console.log(conn)
    console.log("DB Connection successful");
  })
  .catch((err)=>{
    console.log(err);
  })

  const MovieSchema = new mongoose.Schema({
    // required for mandatory field and unique is for not allowed duplicate value
    name:{type:String,required:true,unique:true},
    ReleaseYear:{type:Number,required:[true,'release year is mandatory!']},
    duration:Number,
    description:String,
    ratings:{type:Number,default:1.0}
  })

 const MovieModel = mongoose.model('Movieflixcollection',MovieSchema);

  //  const testMovie = new MovieModel({
  //   name: "Freelancer 3",
  //   ReleaseYear:2021,
  //   duration:180,
  //   description:"action",
  //   ratings:4
  //  })

// testMovie.save();


module.exports = MovieModel;
