
const fs=require('fs');

//const movies = JSON.parse(fs.readFileSync("./movies.json"));
// console.log(movies);

const MovieModel = require('../Models/movieModel')

exports.getallmovies = async(req,res)=>{
   try{
    const allMovies = await MovieModel.find();
    res.status(200).json({
    "status":"Sucess",
    "data":allMovies,
    "requestTime":req.startTime
   })
}catch(err){
    res.status(404).json({
        status:"fail",
        message:err.message
})
}
}


exports.addnewmovie = async (req,res)=>{
    try{
    const Movie = await MovieModel.create(req.body);
     res.status(201).json({
        status:"Sucsess",
        data:{Movie}
    })
    }catch(err){
    res.status(404).json({
       status:"fail",
       message:err.message 
    })
}
}


exports.getmoviebyid = async(req,res)=>{

    const movieid = req.params.mid;
    // console.log(movieid)
    // res.send("done")
    try{
       const oneMovie = await MovieModel.find({_id:movieid}) 
    if(oneMovie.length==0){    
        res.status(200).json({
            "status":"Failure",
            "message":"Sorry that movie is not present"
        })}else{
            res.status(200).json({
            "status":"success",
            "data":{oneMovie}
        })}
    }catch(err){
        res.status(404).json({
            status:"Failure",
            message:err.message
        })
    }
}



exports.updatemoviebyput = async(req,res)=>{
    const movieid = req.params.mid;
    // console.log(movieid)
    // res.send("done")
    try{
       const oneMovie = await MovieModel.findByIdAndUpdate(movieid,req.body,{new:true,runValidators:true}) 
    if(oneMovie.length==0){    
        res.status(200).json({
            "status":"Failure",
            "message":"Sorry that movie is not present , cant update !!"
        })}else{
            res.status(200).json({
            "status":"success",
            "data":{oneMovie}
        })}
    }catch(err){
        res.status(404).json({
            status:"Failure",
            message:err.message
        })
    }
}


exports.deletemovie = async(req,res)=>{
    const movieid = req.params.mid;
    try{
       await MovieModel.findByIdAndDelete(movieid) 
        res.status(200).json({
            status:"success",
            message:"Movie deleted"
        })
    }catch(err){
        res.status(404).json({
            status:"Failure",
            message:err.message
        })
}}


exports.deleteallmovies = async(req,res)=>{
    try{
       await MovieModel.deleteMany({}) 
        res.status(200).json({
            status:"success",
            message:"All Movies deleted"
        })
    }catch(err){
        res.status(404).json({
            status:"Failure",
            message:err.message
        })
}
}