const express = require('express');
const movieRouter = express.Router();
const movieLogic= require('../Controller/movieLogic')

//movie logic = {getmoviebyid etc}

const {getallmovies,getmoviebyid,getmoviebyryear,updatemoviebypatch,updatemoviebyput,addnewmovie,deleteallmovies,deletemovie} = movieLogic;

// trying to do refactoring using ROUTE HANDLERS

movieRouter.route('/movies/:mid').put(updatemoviebyput).delete(deletemovie).get(getmoviebyid);;
movieRouter.route('/movies').get(getallmovies).post(addnewmovie).delete(deleteallmovies);

module.exports = movieRouter